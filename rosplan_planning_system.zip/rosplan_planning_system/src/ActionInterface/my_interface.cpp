#include "rosplan_action_interface/my_interface.h"


/* The implementation of RPTutorial.h */
namespace KCL_rosplan {

	/* constructor */
	RPTutorialInterface::RPTutorialInterface(std::string &actionserver) : action_client_(actionserver, true)  {
		// create a node handle to manage communication with ROS network
		        ros::NodeHandle nh("~");


		// perform setup
	}


	/* action dispatch callback */
	bool RPTutorialInterface::concreteCallback(const rosplan_dispatch_msgs::ActionDispatch::ConstPtr& msg) {

		// The action implementation goes here.

		// complete the action

		ROS_INFO("KCL: (%s) waiting for Myaction action server to start", params.name.c_str());
			 action_client_.waitForServer();

			 // dispatch myaction action
			 robot_manipulator::MyActionGoal goal;
			 goal.order =  params.name.c_str();
			 action_client_.sendGoal(goal);


		bool finished_before_timeout = action_client_.waitForResult();

		// ROS_INFO("KCL: finished_before_timeout: %s", finished_before_timeout);


        if (finished_before_timeout) {

            actionlib::SimpleClientGoalState state = action_client_.getState();
            ROS_INFO("KCL: (%s) action finished: %s", params.name.c_str(), state.toString().c_str());

            if(state == actionlib::SimpleClientGoalState::SUCCEEDED) {

                // publish feedback (achieved)
                return true;

            } else {



                // publish feedback (failed)
                return false;
            }
        } else {
            // timed out (failed)
            action_client_.cancelAllGoals();
            ROS_INFO("KCL: (%s) action timed out", params.name.c_str());
            return false;
        }

        }


    }

	  // ROS_INFO("KCL: (%s) Action completing.", msg->name.c_str());
		//
		// return true;

 // close namespace

	/*-------------*/
	/* Main method */
	/*-------------*/

	int main(int argc, char **argv) {

		ros::init(argc, argv, "my_interface");
		ros::NodeHandle nh("~");
		std::string actionserver;
		nh.param("MyActionServer",actionserver, std::string("/MyActionServer"));

		// create PDDL action subscriber
		KCL_rosplan::RPTutorialInterface rpmb(actionserver);


		rpmb.runActionInterface();

		return 0;
	}
