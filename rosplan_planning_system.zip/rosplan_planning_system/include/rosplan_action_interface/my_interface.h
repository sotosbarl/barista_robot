#include <ros/ros.h>
#include <vector>
#include "rosplan_action_interface/RPActionInterface.h"
#include <actionlib/client/simple_action_client.h>
#include <actionlib/client/terminal_state.h>
#include <robot_manipulator/MyActionAction.h>



#ifndef KCL_tutorial_10
#define KCL_tutorial_10

/**
 * This file defines an action interface created in tutorial 10.
 */
namespace KCL_rosplan {

	class RPTutorialInterface: public RPActionInterface
	{

	private:

	public:

		/* constructor */
		RPTutorialInterface(std::string & actionserver);

		/* listen to and process action_dispatch topic */
		bool concreteCallback(const rosplan_dispatch_msgs::ActionDispatch::ConstPtr& msg);
		actionlib::SimpleActionClient<robot_manipulator::MyActionAction> action_client_;
	
};
}
#endif
